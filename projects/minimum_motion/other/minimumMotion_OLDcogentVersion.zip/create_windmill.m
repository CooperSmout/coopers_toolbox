%% create_windmill.m
% creates image matrices that input to minimum_motion_staircase.m
% creates image matrix for each frame of a movie, for all green RGB values

clear
clc

close('all')
%input('press enter')

% image size
w = 400; % resolution x
h = 400; % resolution y
x = 1:w;
y = 1:h;
ox = w/2;
oy = h/2;

maxrad = 137.5; % inner radius of windmill
minrad = 70.5; % outer radius of windmill

% coordinates
[X,Y] = meshgrid(x-ox,y-oy); % cartesian coords in 400 x 400 matrix
[TH, R] = cart2pol(X,Y); % converts each cartesian coordinate to polar coords in 400 x 400 matrix
TH = rem(TH + 2*pi, 2*pi); % shift from -pi:pi to 0:2pi
inc = pi/120; % determines pixation or no
% T = [ (0:inc:2*pi - inc)' (inc:inc:2*pi)' ];
% t = inc:inc:2*pi;

% variables

cycles = 6; % number of times cycling in 360 degrees
lure = .16; % maximum modulation of luminance lure (x2)
rad = 0:inc:2*pi-inc; % radial segments in space (the windmill)
radnext = inc:inc:2*pi; % next radial segment beyond current one
testspeed = 1; % higher test speed -> quicker test run (minimum 1)

redrgb = 255; % red phoshor rgb value --- set to 255 for max modulation
Mr = redrgb/255; % modulation of red phosphor, 1 allows max modulation of red phosphor (between 1 and 0)

redGamma = 2.4550;
greenGamma = 2.3354;
% blueGamma = 2.4279;

rgb_array = [ 1:255 ];

%for greenrgb = 79.7273 
for n = 1:length(rgb_array) ; % equivalent green rgb value to be put into subsequent experiment
    
    real_rgb = rgb_array(n)
    
    clear IM;
    
    greenrgb = (real_rgb/255).^greenGamma*255
    Mg = greenrgb/255; % modulation of green phosphor expressed as a fraction of 1
    
    count = 0;
    
    for time = 0:2*pi/(60/testspeed):2*pi - 2*pi/(60/testspeed);

        disp(time)

        count = count + 1;

% phosphor equations
        phosphor(:,1) = Mr/2 + .5*Mr*cos( cycles*rad )*cos( time ) + .5*Mr*lure*sin( cycles*rad )*sin( time ) ; % colour grating component + luminance grating component
        phosphor(:,2) = Mg/2 - .5*Mg*cos( cycles*rad )*cos( time ) + .5*Mg*lure*sin( cycles*rad )*sin( time ) ; % colour grating component + luminance grating component
        phosphor(:,3) = 0; 

        phosphor(:,1) = phosphor(:,1) .^ (1/redGamma);
        phosphor(:,2) = phosphor(:,2) .^ (1/greenGamma);
        % imCorr = ((imUncorr/255) .^ (1/gammaValue)) * 255;


        wmR = zeros(h,w);
        wmG = zeros(h,w);
        wmB = zeros(h,w);   
        
        for RR = 1:length(rad);

            wmR( ( TH >= rad(RR) & TH <= radnext(RR) ) & ( R > minrad & R < maxrad ) ) = phosphor(RR,1); % red phosphor intensity of windmill
            wmG( ( TH >= rad(RR) & TH <= radnext(RR) ) & ( R > minrad & R < maxrad ) ) = phosphor(RR,2); % green phosphor intensity of windmill   
            wmB( ( TH >= rad(RR) & TH <= radnext(RR) ) & ( R > minrad & R < maxrad ) ) = phosphor(RR,3); % blue phosphor intensity of windmill
                    
        end

        im = cat(3, wmR, wmG, wmB );

        IM(:,:,:,count) = im;

    end
    
    IM = round(IM*10000)/10000;
    
    save( [ 'stim/IM' num2str(real_rgb) '.mat'], 'IM')
%    save( [ 'IM' num2str(greenrgb) 'equiv_greenrgb' '.mat'], 'IM')

    
end


    